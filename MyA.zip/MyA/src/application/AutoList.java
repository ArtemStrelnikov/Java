package application;

import javafx.fxml.FXML;
import javafx.scene.image.ImageView;

public class AutoList {

    @FXML
    private ImageView audimg;

    @FXML
    private ImageView bmwImg;

}

