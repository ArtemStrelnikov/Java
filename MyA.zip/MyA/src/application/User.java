package application;

public class User {
	
	
	
	
	private String firstname;
	private String lastname;
	private String reglogin;
	private String password;
	
	
	
	public User(String firstname, String lastname, String reglogin, String password) {
		super();
		this.firstname = firstname;
		this.lastname = lastname;
		this.reglogin = reglogin;
		this.password = password;
	}
	
	

	
	
	public User() {           //нужно ли добавить пустой конструктор?
	
	}





	/**
	 * @return the firstname
	 */
	public String getFirstname() {
		return firstname;
	}
	/**
	 * @param firstname the firstname to set
	 */
	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}
	/**
	 * @return the lastname
	 */
	public String getLastname() {
		return lastname;
	}
	/**
	 * @param lastname the lastname to set
	 */
	public void setLastname(String lastname) {
		this.lastname = lastname;
	}
	/**
	 * @return the reglogin
	 */
	public String getReglogin() {
		return reglogin;
	}
	/**
	 * @param reglogin the reglogin to set
	 */
	public void setReglogin(String reglogin) {
		this.reglogin = reglogin;
	}
	/**
	 * @return the password
	 */
	public String getPassword() {
		return password;
	}
	/**
	 * @param password the password to set
	 */
	public void setPassword(String password) {
		this.password = password;
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

	}
