package application;

import java.sql.SQLException;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;

public class Regist {

    @FXML
    private TextField RegLastName;

    @FXML
    private PasswordField RegLogin;

    @FXML
    private TextField RegName;

    @FXML
    private Button RegNextButt;

    @FXML
    private PasswordField RegPassword;

    @FXML
    void reglastname(ActionEvent event) {

    }

    @FXML
    void reglogin(ActionEvent event) {

    }

    @FXML
    void regname(ActionEvent event) {

    }
    
    
    
    
    
    
    
    
    
    

    @FXML
    void regnextbutt(ActionEvent event) throws ClassNotFoundException, SQLException { //throws ClassNotFoundException, SQLException -  DELITE???
     	
    	
    	signUpNewUser();
    	

    }

    private void signUpNewUser() throws ClassNotFoundException, SQLException { // throws ClassNotFoundException, SQLException DELITE????????
    	
    	DatabaseHandler dbHandler = new DatabaseHandler();
    	
    	
    	 String firstname = RegName.getText();
    	 String lastname = RegLastName.getText();  
    	 String reglogin = RegLogin.getText();
    	 String password = RegPassword.getText();
    	 
    	 
    	 User user = new User(firstname,lastname,reglogin,password);
    	 
    	
    	
    	
    	dbHandler.signUpUser(user);
    	
	
		
	}
    
    
	@FXML
    void regpassword(ActionEvent event) {

    }

}
