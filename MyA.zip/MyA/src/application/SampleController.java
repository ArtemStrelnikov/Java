package application;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
//import javafx.scene.Parent;
//import javafx.scene.Stage;
import javafx.stage.Stage;

public class SampleController {

    @FXML
    private TextField NameButt;

    @FXML
    private Button NextB;

    @FXML
    private PasswordField PasswordButt;

    @FXML
    private Button RegButt;

    @FXML
    void name(ActionEvent event) {
    	

    }

    @FXML
    void nextButton(ActionEvent event) {
    	
    	
    	
	
	String loginText = NameButt.getText().trim();
	String loginPassword = PasswordButt.getText().trim();
	
	
	
	if(!loginText.equals("") && !loginPassword.equals("")){
	loginUser (loginText, loginPassword);
	}
	
	else
	System.out.println("Login and passwoed is empty");
	
	
	
	
	
	};
	  
	  
    @FXML
    void password(ActionEvent event) {
    	
    	

    }
    
  
    @FXML
    void regist(ActionEvent event) {
    	
    	FXMLLoader loader = new FXMLLoader();
		loader.setLocation(getClass().getResource("/application/Sample2.fxml"));
		
		try {
			loader.load();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		Parent root = loader.getRoot();
		Stage stage = new Stage ();
		stage.setScene(new Scene(root));
		stage.showAndWait();
    	
    	
    	
    }
    
    private void loginUser (String loginText, String loginPassword) {
    		DatabaseHandler dbHandler = new DatabaseHandler();
    		User user = new User();
    		user.setReglogin(loginText);
    		user.setPassword(loginPassword);
    		ResultSet result = dbHandler.getUser(user);
    		
    		
    		int counter = 0;
    		
    		try {
				while(result.next()) {
					counter++;
				}
			} catch (SQLException e) {
				
				e.printStackTrace();
			}
    		
    		if(counter >= 1 ) {
    		//	System.out.println("Success!");
    			
    			
    			FXMLLoader loader = new FXMLLoader();
    			loader.setLocation(getClass().getResource("/application/Sample1.fxml"));
    			
    			try {
    				loader.load();
    			} catch (IOException e) {
    				e.printStackTrace();
    			}
    			
    			Parent root = loader.getRoot();
    			Stage stage = new Stage ();
    			stage.setScene(new Scene(root));
    			stage.showAndWait();
    	    	
    			
    			
    			
    			
    			
    		}
    		
    };
    

}
