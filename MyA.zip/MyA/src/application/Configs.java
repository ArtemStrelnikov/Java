package application;

public class Configs {
	
	protected String dbHost = "localhost";
	protected String dbPort = "3306";
	protected String dbUser = "root";
	protected String dbPass = "Arch10525";
	protected String dbName = "users";
	
	
	///hostname 127.0.0.1

}
